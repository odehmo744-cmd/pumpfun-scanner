const http = require("http");
const fs = require("fs");
const path = require("path");
const { PublicKey, Connection } = require("@solana/web3.js");

const PORT = process.env.PORT || 8787;
const RPC = process.env.SOLANA_RPC_URL || "https://rpc.solanatracker.io/public";
const connection = new Connection(RPC, "confirmed");
const PUMP_PROGRAM = new PublicKey("6EF8rrecthR5Dkzon8Nwu78hRvfCKubJ14M5uBEwF6P");

function json(res, code, data) {
  res.writeHead(code, {"Content-Type":"application/json; charset=utf-8","Access-Control-Allow-Origin":"*"});
  res.end(JSON.stringify(data));
}
function b64(buf){ return Buffer.from(buf,"base64"); }
function u64le(buf, off){ return Number(buf.readBigUInt64LE(off)); }

function extractMint(input){
  const s = String(input||"").trim();
  const m = s.match(/[1-9A-HJ-NP-Za-km-z]{32,44}(?:pump)?/);
  if (!m) throw new Error("لم أجد Contract Address صالح في الرابط.");
  return m[0];
}

async function dex(mint){
  try {
    const r=await fetch(`https://api.dexscreener.com/token-pairs/v1/solana/${mint}`);
    if(!r.ok) return null;
    const x=await r.json();
    return x?.[0] || null;
  } catch(e){ return null; }
}

async function tokenHolders(mint){
  const largest=await connection.getTokenLargestAccounts(new PublicKey(mint));
  const accounts=largest.value.slice(0,20);
  if(!accounts.length) return [];
  const infos=await connection.getMultipleAccountsInfo(accounts.map(x=>new PublicKey(x.address)));
  return accounts.map((a,i)=>{
    const d=infos[i]?.data;
    let owner=null;
    if(Buffer.isBuffer(d) && d.length>=64) owner=new PublicKey(d.subarray(32,64)).toBase58();
    return {tokenAccount:a.address, owner, amount:Number(a.uiAmount||0)};
  });
}

async function txStats(mint){
  const sigs=await connection.getSignaturesForAddress(new PublicKey(mint), {limit:80});
  const recent=sigs.slice(0,50);
  const buyers=new Set(), sellers=new Set();
  let buyCount=0,sellCount=0;
  const first = sigs.length ? sigs[sigs.length-1].signature : null;
  for(const s of recent){
    try{
      const tx=await connection.getParsedTransaction(s.signature,{maxSupportedTransactionVersion:0});
      if(!tx) continue;
      const pre=new Map(), post=new Map();
      for(const b of (tx.meta?.preTokenBalances||[])) if(b.mint===mint) pre.set(b.owner,b.uiTokenAmount.uiAmount||0);
      for(const b of (tx.meta?.postTokenBalances||[])) if(b.mint===mint) post.set(b.owner,b.uiTokenAmount.uiAmount||0);
      const owners=new Set([...pre.keys(),...post.keys()]);
      for(const o of owners){
        const d=(post.get(o)||0)-(pre.get(o)||0);
        if(d>0){buyers.add(o);buyCount++;}
        if(d<0){sellers.add(o);sellCount++;}
      }
    }catch(_){}
  }
  return {recentTxs:recent.length, uniqueBuyers:buyers.size, uniqueSellers:sellers.size, buyCount, sellCount, firstSignature:first};
}

async function analyze(input){
  const mintStr=extractMint(input);
  const mint=new PublicKey(mintStr);
  const [curve]=PublicKey.findProgramAddressSync([Buffer.from("bonding-curve"), mint.toBuffer()], PUMP_PROGRAM);
  const [info, pair, holders, stats] = await Promise.all([
    connection.getAccountInfo(curve),
    dex(mintStr),
    tokenHolders(mintStr),
    txStats(mintStr)
  ]);

  let curveData=null;
  if(info?.data){
    const d=info.data;
    // Anchor discriminator (8), then five u64s, bool at 48; creator fields may exist in newer layouts.
    if(d.length>=8+8*5+1){
      curveData={
        virtualToken:u64le(d,8),
        virtualSol:u64le(d,16),
        realToken:u64le(d,24),
        realSol:u64le(d,32),
        totalSupply:u64le(d,40),
        complete:Boolean(d[48])
      };
    }
  }

  const total=curveData?.totalSupply || 1_000_000_000;
  const top=holders.filter(x=>x.owner && x.owner!==curve.toBase58());
  const topPct=top.slice(0,10).reduce((a,x)=>a+x.amount,0)/total*100;
  const top1Pct=(top[0]?.amount||0)/total*100;

  let score=50, reasons=[];
  if(curveData?.complete){ score=35; reasons.push("Bonding curve مكتملة/انتقلت من مرحلة الإطلاق."); }
  else { score+=10; reasons.push("العملة ما زالت على bonding curve."); }
  if(topPct<20){score+=15; reasons.push("Top 10 concentration منخفضة نسبيًا.");}
  else if(topPct>40){score-=20; reasons.push("تركيز Top 10 مرتفع.");}
  if(top1Pct<8){score+=8;} else if(top1Pct>20){score-=15; reasons.push("أكبر holder يملك نسبة كبيرة.");}
  if(stats.uniqueBuyers>=10 && stats.uniqueBuyers>stats.uniqueSellers){score+=12; reasons.push("تدفق المشترين أفضل من البائعين في العينة الأخيرة.");}
  else if(stats.uniqueSellers>stats.uniqueBuyers*1.2){score-=12; reasons.push("البائعون متفوقون في العينة الأخيرة.");}
  if(pair){
    const tx5=pair.txns?.m5||{};
    const buys=tx5.buys||0, sells=tx5.sells||0;
    if(buys>sells*1.5){score+=10; reasons.push("Buy pressure قوي على DEX.");}
    else if(sells>buys*1.5){score-=10; reasons.push("Sell pressure قوي على DEX.");}
  } else if(!curveData?.complete){
    reasons.push("لم يظهر Pair على DEX Screener بعد؛ البيانات المبكرة محدودة.");
    score-=3;
  }
  score=Math.max(0,Math.min(100,Math.round(score)));
  let verdict=score>=80?"BUY CANDIDATE":score>=65?"WATCH":"AVOID";
  if(score>=80 && (topPct>45 || top1Pct>25)) verdict="AVOID";
  return {
    mint:mintStr, score, verdict,
    ageHint: pair?.pairCreatedAt ? Math.max(0,Date.now()-pair.pairCreatedAt) : null,
    curve:curveData,
    curveAddress:curve.toBase58(),
    top1Pct:Number(top1Pct.toFixed(2)),
    top10Pct:Number(topPct.toFixed(2)),
    holders:top.slice(0,10),
    stats,
    dex: pair ? {
      priceUsd:pair.priceUsd, marketCap:pair.marketCap, fdv:pair.fdv,
      liquidityUsd:pair.liquidity?.usd,
      m5:pair.txns?.m5, m15:pair.txns?.m15, h1:pair.txns?.h1,
      volumeM5:pair.volume?.m5, volumeH1:pair.volume?.h1,
      priceChangeM5:pair.priceChange?.m5, priceChangeH1:pair.priceChange?.h1,
      url:pair.url
    }:null,
    reasons,
    disclaimer:"هذا Scanner احتمالي وليس ضمانًا للربح. V1 لا ينفذ شراء ولا يطلب private key."
  };
}

const html=fs.readFileSync(path.join(__dirname,"index.html"));
const server=http.createServer(async(req,res)=>{
  if(req.method==="GET" && req.url==="/"){res.writeHead(200,{"Content-Type":"text/html; charset=utf-8"});return res.end(html);}
  if(req.method==="GET" && req.url.startsWith("/api/analyze")){
    try{
      const u=new URL(req.url,"http://localhost");
      const input=u.searchParams.get("url")||"";
      if(!input) return json(res,400,{error:"ضع رابط Pump.fun أولاً."});
      const out=await analyze(input); return json(res,200,out);
    }catch(e){return json(res,400,{error:e.message||"Analysis failed"});}
  }
  res.writeHead(404);res.end("Not found");
});
server.listen(PORT,()=>console.log(`Pump Scanner V1: http://localhost:${PORT}`));
