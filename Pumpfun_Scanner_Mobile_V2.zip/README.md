# Pump.fun Scanner V1

## تشغيل
1. ثبّت Node.js 20 أو أحدث.
2. افتح Terminal داخل المجلد.
3. شغّل:
   npm install
   npm start
4. افتح: http://localhost:8787

ضع رابط Pump.fun واضغط ANALYZE.

## ماذا يفحص؟
- Bonding curve state on-chain.
- Top holder concentration.
- آخر نشاطات token ومحاولة تقدير buyers/sellers.
- DEX Screener: market cap, liquidity, volume, buys/sells.
- Score + BUY CANDIDATE / WATCH / AVOID.

## ملاحظات
V1 لا ينفذ صفقات ولا يطلب private key.
التحليل احتمالي وليس ضماناً للربح.
النسخة الأولى متعمدة أن تكون بسيطة؛ الخطوة التالية هي إضافة creator history، funding relationships/bundles، smart-wallet history، وstreaming لحظي.
