# Pump.fun Scanner Mobile V2

نسخة مهيأة للموبايل. الواجهة قابلة للفتح من المتصفح، لكن التحليل الحقيقي للـon-chain يحتاج API/backend أو proxy لأن بعض APIs لا تسمح بطلبات مباشرة من المتصفح بسبب CORS.

المصادر المستخدمة/المناسبة:
- Pump.fun bonding curve: https://pump.fun/docs/bonding-curve
- DEX Screener API: https://docs.dexscreener.com/api/reference

طريقة الاستخدام:
1. افتح index.html في بيئة تستضيف ملفات HTML.
2. الصق Pump.fun URL أو Contract Address.
3. اضغط Analyze.

ملاحظة: لا يتم اعتبار أي Score ضماناً للربح؛ هذه أداة فرز للمخاطر.
